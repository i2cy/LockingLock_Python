# ESP32S3 LockingLock Server

This repo is the server part of LockingLock project.

Project is still under development.

[Github Link](https://github.com/i2cy/LockingLock_Python)

# Installation
`pip install i2llserver`

# Setup
`i2llsrv setup`

This command will help you to edit a configuration file and 
add startup scripts on boot in systemd
